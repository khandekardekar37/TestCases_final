# validator/cli.py
from pathlib import Path
from validator.validator import validate_testcases
from config import MODE
import sys

# Add project root to sys.path
sys.path.append(str(Path(__file__).parent.parent.resolve()))


def main():
    print("📥 Standalone Validator CLI")

    req_path = Path(input("Enter path to requirements JSON file: ").strip())
    tc_path = Path(input("Enter path to testcases TXT file: ").strip())

    if not req_path.exists() or not tc_path.exists():
        print("❌ Invalid file paths provided.")
        return

    # Standalone: feedback loop OFF
    coverage, missing, completeness, accuracy = validate_testcases(
        requirement_file=req_path,
        testcase_file=tc_path
    )

    print("\n✅ Validation completed in Standalone mode.")
    print(f"Completeness: {completeness}%, Accuracy: {accuracy}%")
    print(f"Missing Requirements: {len(missing)}")

if __name__ == "__main__":
    main()
