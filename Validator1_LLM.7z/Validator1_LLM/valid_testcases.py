# import ollama
# import json
# import pandas as pd

# # 1. LOAD DATA
# with open('requirements.json', 'r') as f:
#     requirements = json.load(f)
# with open('testcases.json', 'r') as f:
#     test_cases = json.load(f)

# results = []

# def validate_coverage(req, all_tcs):
#     """Ask DeepSeek-R1 to verify if a requirement is covered by the list of TCs."""
#     prompt = f"""
#     SYSTEM: You are a Senior QA Auditor. Answer ONLY in JSON format.
#     TASK: Verify if the following Requirement is covered by the provided list of Test Cases.
    
#     REQUIREMENT: {req['requirement']}
#     TEST CASES: {json.dumps(all_tcs)}
    
#     RETURN JSON FORMAT:
#     {{
#         "req_id": "{req['id']}",
#         "is_covered": true/false,
#         "matching_tc_id": "TC-XXX or None",
#         "accuracy_score": 0-100,
#         "reason": "Brief explanation of why it is accurate or why it is missing."
#     }}
#     """
    
#     # Using 'options' to set temperature=0 for consistency
#     response = ollama.chat(
#         model='deepseek-r1:7b',
#         messages=[{'role': 'user', 'content': prompt}],
#         options={'temperature': 0, 'seed': 42}
#     )
    
#     # Extract JSON from the thinking-process-wrapped response
#     content = response['message']['content']
#     # Cleaning the response (stripping <think> tags if present)
#     json_str = content.split('```json')[-1].split('```')[0].strip() if '```json' in content else content
#     return json.loads(json_str)

# # 2. RUN VALIDATION
# print("Starting Validation...")
# for req in requirements:
#     print(f"Validating {req['id']}...")
#     val_result = validate_coverage(req, test_cases)
#     results.append(val_result)

# # 3. GENERATE REPORT
# df = pd.DataFrame(results)

# # Calculate Metrics
# total_reqs = len(requirements)
# covered_reqs = df[df['is_covered'] == True].shape[0]
# completeness = (covered_reqs / total_reqs) * 100
# avg_accuracy = df[df['is_covered'] == True]['accuracy_score'].mean()

# print("\n--- FINAL REPORT ---")
# print(f"Completeness Score: {completeness:.2f}%")
# print(f"Average Accuracy of Matches: {avg_accuracy:.2f}%")

# # Show Missing Requirements
# missing = df[df['is_covered'] == False]
# if not missing.empty:
#     print("\n--- MISSING REQUIREMENTS (Action Needed) ---")
#     print(missing[['req_id', 'reason']])

# df.to_excel("Validation_Report.xlsx", index=False)





# import asyncio
# import json
# import pandas as pd
# import re
# from ollama import AsyncClient

# # 1. Config
# MAX_CONCURRENT_TASKS = 3
# semaphore = asyncio.Semaphore(MAX_CONCURRENT_TASKS)

# def clean_llm_json(text):
#     """
#     DeepSeek-R1 outputs <think> tags and markdown blocks. 
#     This function strips them to find the raw JSON.
#     """
#     # Remove <think> blocks
#     text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
#     # Find JSON block
#     match = re.search(r'\{.*\}', text, re.DOTALL)
#     if match:
#         return match.group(0)
#     return text

# async def validate_coverage_async(client, req, all_tcs):
#     async with semaphore:
#         prompt = f"""
#         SYSTEM: You are a strict Software Quality Auditor. 
#         TASK: Check if the 'Requirement' is covered by the 'Test Cases'.
        
#         REQUIREMENT: {req['requirement']}
#         TEST CASES: {json.dumps(all_tcs)}
        
#         RULES:
#         1. If the exact logic or condition of the requirement is not present in the steps of at least one test case, 'is_covered' MUST be false.
#         2. Provide an accuracy score (0-100).
#         3. Respond ONLY in this JSON format:
#         {{"req_id": "{req['id']}", "is_covered": true, "matching_tc_id": "TC-XXX", "accuracy_score": 95, "reason": "Explanation"}}
#         """
        
#         try:
#             response = await client.chat(
#                 model='deepseek-r1:7b',
#                 messages=[{'role': 'user', 'content': prompt}],
#                 options={'temperature': 0}
#             )
            
#             raw_content = response['message']['content']
#             # Clean the DeepSeek 'thinking' and markdown
#             clean_json = clean_llm_json(raw_content)
#             return json.loads(clean_json)
            
#         except Exception as e:
#             # If parsing fails, we return the error so we can see what happened
#             return {"req_id": req['id'], "is_covered": False, "accuracy_score": 0, "reason": f"Parsing Error: {str(e)}"}

# async def main():
#     # Your Data (SSD and Testcases)
#     requirements = [
#         {"id": "REQ-01", "requirement": "Currently, when adding an additional driver... action buttons (print, transmit, upload) should be disabled..."},
#         {"id": "REQ-03", "requirement": "If Age is below 18... alert 'Applicant age not in Range'... action buttons disabled except Reset."},
#         # ... (Add the rest of your 36 requirements here)
#     ]
    
#     test_cases = [
#         {"tc_id": "TC-102", "steps": "Verify that when driver's age is less than 18 years, then system show the error message 'Applicant age is not in Range'."},
#         {"tc_id": "TC-103", "steps": "Verify that when driver's age is less than 18 years... disables below action buttons: Print, Scan & Upload, Browse & Upload, Transmit"},
#         # ... (Add the rest of your 10 testcases here)
#     ]

#     client = AsyncClient()
#     print(f"Analyzing {len(requirements)} requirements against {len(test_cases)} test cases...")
    
#     tasks = [validate_coverage_async(client, r, test_cases) for r in requirements]
#     results = await asyncio.gather(*tasks)
    
#     # Generate Report
#     df = pd.DataFrame(results)
#     print("\n--- VALIDATION SUMMARY ---")
#     print(df[['req_id', 'is_covered', 'accuracy_score', 'reason']])
    
#     # Save to Excel for your stakeholders
#     df.to_excel("Coverage_Report2.xlsx", index=False)

# if __name__ == "__main__":
#     asyncio.run(main())





# Actual Running Code

import asyncio
import json
import pandas as pd
import re
import os
from ollama import AsyncClient

# --- CONFIGURATION ---
# Adjust based on your PC's RAM/GPU. Start with 2 or 3.
MAX_CONCURRENT_TASKS = 3 
MODEL_NAME = "llama3.2:1b"
semaphore = asyncio.Semaphore(MAX_CONCURRENT_TASKS)

def extract_json_from_thinking_model(text):
    """
    Cleans the output of DeepSeek-R1 by removing <think> tags 
    and extracting only the JSON block.
    """
    # 1. Remove the reasoning/thought process
    text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
    
    # 2. Find the JSON content (look for first { and last })
    match = re.search(r'\{.*\}', text, re.DOTALL)
    if match:
        return match.group(0)
    return text

async def validate_requirement(client, req, all_tcs):
    """Sends one requirement to the LLM for validation."""
    async with semaphore:
        prompt = f"""
        SYSTEM: You are a Professional QA Auditor. 
        TASK: Determine if the 'Requirement' is logically covered by the provided 'Test Cases'.
        
        REQUIREMENT: {req['requirement']}
        TEST CASES: {json.dumps(all_tcs)}
        
        INSTRUCTIONS:
        - A requirement is 'covered' if a test case validates its core logic.
        - If a requirement mentions specific messages or button states (like REQ-01/REQ-03), check if the test cases mention them.
        - Respond ONLY in valid JSON. No other text.

        JSON STRUCTURE:
        {{
            "req_id": "{req['id']}",
            "is_covered": true/false,
            "matching_tc_id": "TC-XXX or None",
            "accuracy_score": 0-100,
            "reason": "Explain briefly why it matches or why it is missing."
        }}
        """
        
        try:
            response = await client.chat(
                model=MODEL_NAME,
                messages=[{'role': 'user', 'content': prompt}],
                options={'temperature': 0} # Lock randomness for accuracy
            )
            
            raw_content = response['message']['content']
            clean_json_str = extract_json_from_thinking_model(raw_content)
            
            # Parse the cleaned string into a Python dictionary
            return json.loads(clean_json_str)
            
        except Exception as e:
            return {
                "req_id": req['id'], 
                "is_covered": False, 
                "matching_tc_id": "None", 
                "accuracy_score": 0, 
                "reason": f"System Error: {str(e)}"
            }

async def main():
    # 1. Load your local JSON files
    if not os.path.exists('requirements.json') or not os.path.exists('testcases.json'):
        print("Error: 'ssd.json' or 'te.json' not found in this folder!")
        return

    # ADD encoding='utf-8' HERE
    with open('requirements.json', 'r', encoding='utf-8') as f:
        requirements = json.load(f)
        
    # ADD encoding='utf-8' HERE
    with open('testcases.json', 'r', encoding='utf-8') as f:
        test_cases = json.load(f)

    # 1. Load your local JSON files
    # if not os.path.exists('requirements.json') or not os.path.exists('testcases.json'):
    #     print("Error: 'ssd.json' or 'testcases.json' not found in this folder!")
    #     return

    # with open('requirements.json', 'r') as f:
    #     requirements = json.load(f)
    # with open('testcases.json', 'r') as f:
    #     test_cases = json.load(f)

    client = AsyncClient()
    print(f"--- Starting Analysis of {len(requirements)} Requirements ---")
    
    # 2. Create parallel tasks
    tasks = [validate_requirement(client, req, test_cases) for req in requirements]
    
    # 3. Run and gather results
    results = await asyncio.gather(*tasks)
    
    # 4. Generate Report
    df = pd.DataFrame(results)
    
    # Clean up display
    pd.set_option('display.max_colwidth', 50)
    print("\n--- TRACEABILITY REPORT SUMMARY ---")
    print(df[['req_id', 'is_covered', 'accuracy_score', 'matching_tc_id']])
    
    # Save results
    output_file = "deepseek_new_version_Traceability_Report1.xlsx"
    df.to_excel(output_file, index=False)
    print(f"\nReport successfully saved to: {output_file}")

if __name__ == "__main__":
    asyncio.run(main())







# this model deepseek-r1:1.5b taking 4 min to execute

# import asyncio
# import json
# import pandas as pd
# import re
# import os
# from ollama import AsyncClient

# # --- CONFIGURATION ---
# #new model configuration

# MAX_CONCURRENT_TASKS = 4   # Matches OLLAMA_NUM_PARALLEL
# MODEL_NAME = "deepseek-r1:1.5b" # Much faster for high-volume matching
# BATCH_SIZE = 12            # Process 12 requirements per single call
# semaphore = asyncio.Semaphore(MAX_CONCURRENT_TASKS)

# # old model Configuration
# # MAX_CONCURRENT_TASKS = 2  
# # MODEL_NAME = "deepseek-r1:1.5b" # Fast and effective for batching
# # BATCH_SIZE = 5            
# # semaphore = asyncio.Semaphore(MAX_CONCURRENT_TASKS)

# def extract_json_from_thinking_model(text):
#     """Strips <think> tags and handles markdown blocks."""
#     text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
#     match = re.search(r'\[.*\]|\{.*\}', text, re.DOTALL)
#     if match:
#         return match.group(0)
#     return text

# async def validate_batch(client, req_batch, all_tcs):
#     """Processes a group of requirements for speed."""
#     async with semaphore:
#         prompt = f"""
#         SYSTEM: You are a Professional QA Auditor. Respond ONLY with a JSON array.
#         TASK: Check if each Requirement is covered by the Test Cases.
        
#         REQUIREMENTS BATCH: {json.dumps(req_batch)}
#         TEST CASES: {json.dumps(all_tcs)}
        
#         RETURN JSON ARRAY:
#         [
#           {{"req_id": "REQ-XX", "is_covered": true, "matching_tc_id": "TC-XXX", "accuracy_score": 90, "reason": "..."}},
#           ...
#         ]
#         """
#         try:
#             #old code model calling
#             # response = await client.chat(
#             #     model=MODEL_NAME,
#             #     messages=[{'role': 'user', 'content': prompt}],
#             #     options={'temperature': 0}
#             # )

#             response = await client.chat(
#                 model=MODEL_NAME,
#                 messages=[{'role': 'user', 'content': prompt}],
#                 options={
#                     'temperature': 0,
#                     'num_thread': 8,   # Uses 8 CPU cores for processing
#                     'num_predict': 500 # Limits the length of response to prevent rambling
#                 }
#             )

#             raw_content = response['message']['content']
#             clean_json = extract_json_from_thinking_model(raw_content)
#             return json.loads(clean_json)
#         except Exception as e:
#             return [{"req_id": r['id'], "is_covered": False, "accuracy_score": 0, "reason": f"Batch Error: {str(e)}"} for r in req_batch]

# async def main():
#     try:
#         if not os.path.exists('requirements.json') or not os.path.exists('testcases.json'):
#             print("Error: Input JSON files not found!")
#             return

#         with open('requirements.json', 'r', encoding='utf-8') as f:
#             requirements = json.load(f)
#         with open('testcases.json', 'r', encoding='utf-8') as f:
#             test_cases = json.load(f)

#     except Exception as e:
#         print(f"File Load Error: {e}")
#         return

#     batches = [requirements[i:i + BATCH_SIZE] for i in range(0, len(requirements), BATCH_SIZE)]
#     client = AsyncClient()
#     print(f"--- Processing {len(requirements)} Requirements in {len(batches)} Batches ---")
    
#     tasks = [validate_batch(client, batch, test_cases) for batch in batches]
#     batch_results = await asyncio.gather(*tasks)
    
#     # Flatten results
#     final_results = []
#     for sublist in batch_results:
#         if isinstance(sublist, list): final_results.extend(sublist)
#         else: final_results.append(sublist)
    
#     # --- DATA ANALYSIS & REPORTING ---
#     df = pd.DataFrame(final_results)

#     # 1. Calculate Metrics
#     # total_reqs = len(requirements)
#     # covered_count = df['is_covered'].sum()
#     # completeness = (covered_count / total_reqs) * 100
    
#     # # Accuracy only matters for the requirements that ARE covered
#     # covered_df = df[df['is_covered'] == True]
#     # avg_accuracy = covered_df['accuracy_score'].mean() if not covered_df.empty else 0

#     total_reqs = len(requirements)
#     # Ensure is_covered is treated as boolean
#     df['is_covered'] = df['is_covered'].map(lambda x: True if str(x).lower() == 'true' else False)
#     covered_count = int(df['is_covered'].sum())
#     completeness = (covered_count / total_reqs) * 100
#     avg_accuracy = df[df['is_covered'] == True]['accuracy_score'].astype(float).mean() if covered_count > 0 else 0


#     # 2. Identify Missing Requirements
#     missing_reqs = df[df['is_covered'] == False][['req_id', 'reason']]

#     # --- PRINT SUMMARY TO TERMINAL ---
#     print("\n" + "="*50)
#     print("           QA VALIDATION SUMMARY")
#     print("="*50)
#     print(f"Total Requirements:      {total_reqs}")
#     print(f"Requirements Covered:   {covered_count}")
#     print(f"Completeness Score:     {completeness:.2f}%")
#     print(f"Average Match Accuracy: {avg_accuracy:.2f}%")
#     print("="*50)

#     if not missing_reqs.empty:
#         print("\n[!] MISSING REQUIREMENTS DETECTED:")
#         for index, row in missing_reqs.iterrows():
#             print(f"- {row['req_id']}: {row['reason']}")
#     else:
#         print("\n[+] SUCCESS: All requirements are covered by test cases.")

#     # --- SAVE TO EXCEL WITH SUMMARY SHEET ---
#     output_file = "deepsek_new_version_Traceability_Report1.xlsx"
#     with pd.ExcelWriter(output_file) as writer:
#         df.to_excel(writer, sheet_name='Full Traceability', index=False)
        
#         # Create a Summary Sheet
#         summary_data = {
#             "Metric": ["Total Requirements", "Covered", "Completeness %", "Avg Accuracy %"],
#             "Value": [total_reqs, covered_count, f"{completeness:.2f}%", f"{avg_accuracy:.2f}%"]
#         }
#         summary_df = pd.DataFrame(summary_data)
#         summary_df.to_excel(writer, sheet_name='Summary', index=False)

#     print(f"\n[Done] Professional Report saved to: {output_file}")

# if __name__ == "__main__":
#     asyncio.run(main())








#Optinal Correctlly running code 

# import asyncio
# import json
# import pandas as pd
# import re
# import os
# from ollama import AsyncClient

# # --- CONFIGURATION ---
# MAX_CONCURRENT_TASKS = 2  
# MODEL_NAME = "deepseek-r1:1.5b" 
# BATCH_SIZE = 4 # Reduced slightly for higher accuracy per batch           
# semaphore = asyncio.Semaphore(MAX_CONCURRENT_TASKS)

# def extract_json_from_text(text):
#     """Robust extraction of JSON from LLM response."""
#     # Remove thinking tags if model is changed back to DeepSeek
#     text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
#     # Match the JSON array pattern
#     match = re.search(r'\[\s*\{.*\}\s*\]', text, re.DOTALL)
#     if match:
#         return match.group(0)
#     return None

# async def validate_batch(client, req_batch, all_tcs):
#     async with semaphore:
#         # Strict instructions to prevent duplicate/extra output
#         prompt = f"""
#         TASK: Compare {len(req_batch)} Requirements against Test Cases.
        
#         REQUIREMENTS: {json.dumps(req_batch)}
#         TEST CASES: {json.dumps(all_tcs)}
        
#         RULES:
#         1. Return exactly {len(req_batch)} JSON objects in the array.
#         2. One object per REQ_ID in the batch.
#         3. Do not invent new requirements.
        
#         RESPONSE FORMAT (JSON ONLY):
#         [
#           {{"req_id": "REQ-ID", "is_covered": true/false, "matching_tc_id": "TC-ID", "accuracy_score": 0-100, "reason": "..."}}
#         ]
#         """
#         try:
#             response = await client.chat(
#                 model=MODEL_NAME,
#                 messages=[{'role': 'user', 'content': prompt}],
#                 options={'temperature': 0}
#             )
#             raw_content = response['message']['content']
#             clean_json = extract_json_from_text(raw_content)
            
#             if clean_json:
#                 data = json.loads(clean_json)
#                 # Filter out any extra items the LLM might have hallucinated
#                 valid_ids = [r['id'] for r in req_batch]
#                 return [item for item in data if item.get('req_id') in valid_ids]
#             return []
#         except Exception as e:
#             return [{"req_id": r['id'], "is_covered": False, "accuracy_score": 0, "reason": f"Error: {e}"} for r in req_batch]

# async def main():
#     try:
#         with open('requirements.json', 'r', encoding='utf-8') as f:
#             requirements = json.load(f)
#         with open('testcases.json', 'r', encoding='utf-8') as f:
#             test_cases = json.load(f)
#     except Exception as e:
#         print(f"File Error: {e}")
#         return

#     # Batching
#     batches = [requirements[i:i + BATCH_SIZE] for i in range(0, len(requirements), BATCH_SIZE)]
#     client = AsyncClient()
#     print(f"--- Processing {len(requirements)} Requirements ---")
    
#     tasks = [validate_batch(client, batch, test_cases) for batch in batches]
#     batch_results = await asyncio.gather(*tasks)
    
#     # Flatten results
#     final_results = []
#     for sublist in batch_results:
#         final_results.extend(sublist)
    
#     # --- DATA FIX: ENSURE UNIQUE REQUIREMENTS ---
#     # This prevents the "23 out of 12" error by dropping duplicates
#     df = pd.DataFrame(final_results)
#     df = df.drop_duplicates(subset=['req_id'], keep='first')
    
#     # Re-sync with original requirements to ensure nothing was skipped
#     original_ids = [r['id'] for r in requirements]
#     df = df[df['req_id'].isin(original_ids)]

#     # 1. Calculate Metrics (Fixed Logic)
#     total_reqs = len(requirements)
#     # Ensure is_covered is treated as boolean
#     df['is_covered'] = df['is_covered'].map(lambda x: True if str(x).lower() == 'true' else False)
    
#     covered_count = int(df['is_covered'].sum())
#     completeness = (covered_count / total_reqs) * 100
#     avg_accuracy = df[df['is_covered'] == True]['accuracy_score'].astype(float).mean() if covered_count > 0 else 0

#     # 2. Results Section
#     missing_reqs = df[df['is_covered'] == False][['req_id', 'reason']]

#     print("\n" + "="*50)
#     print("           QA VALIDATION SUMMARY")
#     print("="*50)
#     print(f"Total Requirements:      {total_reqs}")
#     print(f"Requirements Covered:   {covered_count}")
#     print(f"Completeness Score:     {completeness:.2f}%")
#     print(f"Average Match Accuracy: {avg_accuracy:.2f}%")
#     print("="*50)

#     # --- SAVE TO EXCEL ---
#     output_file = "deepseek_Traceability_Report1.xlsx"
#     with pd.ExcelWriter(output_file) as writer:
#         df.to_excel(writer, sheet_name='Full Traceability', index=False)
#         summary_df = pd.DataFrame({
#             "Metric": ["Total Requirements", "Covered", "Completeness %", "Avg Accuracy %"],
#             "Value": [total_reqs, covered_count, f"{completeness:.2f}%", f"{avg_accuracy:.2f}%"]
#         })
#         summary_df.to_excel(writer, sheet_name='Summary', index=False)

#     print(f"\n[Done] Report saved to: {output_file}")

# if __name__ == "__main__":
#     asyncio.run(main())


